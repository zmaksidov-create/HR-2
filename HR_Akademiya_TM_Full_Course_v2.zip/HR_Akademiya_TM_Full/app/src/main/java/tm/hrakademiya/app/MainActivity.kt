package tm.hrakademiya.app
import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
class MainActivity : Activity() {
 private lateinit var web: WebView
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  web=WebView(this); web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true
  web.webViewClient=WebViewClient(); web.webChromeClient=WebChromeClient(); setContentView(web)
  web.loadUrl("file:///android_asset/index.html")
 }
 @Deprecated("Deprecated in Android")
 override fun onBackPressed(){ if(::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
}
